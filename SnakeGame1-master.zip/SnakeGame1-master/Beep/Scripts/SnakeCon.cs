﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnakeCon : MonoBehaviour
{
    float speed = 4;
    float rot = 0;
    float rotSpeed = 80;
    float gravity = 8;
    Vector3 DirMove = Vector3.zero;


    CharacterController controller;
    Animator anim;




    // Start is called before the first frame update
    void Start()
    {
        controller = GetComponent<CharacterController>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
		Movement();
		GetInput();
    }
    void Movement()
	{
		if (controller.isGrounded)
		{
			if (Input.GetKey(KeyCode.W))
			{
                if (anim.GetBool("attacking") == true)
                {
                    return;
                }
                else if(anim.GetBool("attacking") == false)
                {
                    anim.SetBool("running", true);
                    anim.SetInteger("condition", 1); // the animation will set it to 1 making it walk
                    DirMove = new Vector3(0, 0, 1);
                    DirMove *= speed;
                    DirMove = transform.TransformDirection(DirMove);
                }
                

			}
			if (Input.GetKeyUp(KeyCode.W))
			{
                anim.SetBool("running", false);
				DirMove = new Vector3(0, 0, 0);
				anim.SetInteger("condition", 0);
			}
			controller.Move(DirMove * Time.deltaTime);
			DirMove.y -= gravity * Time.deltaTime;
			rot += Input.GetAxis("Horizontal") * rotSpeed * Time.deltaTime;
			transform.eulerAngles = new Vector3(0, rot, 0);

		}
        if(Input.GetKeyDown(KeyCode.F))
        {
            anim.SetInteger("condition", 3);
            
        }
        if(Input.GetKeyUp(KeyCode.F))
        {
            anim.SetInteger("condition", 0);
        }
	}
    void GetInput()
	{
        if(controller.isGrounded)
		
            if(Input.GetMouseButtonDown (0))
			{
                if(anim.GetBool("running") == true)
                {
                   anim.SetBool("running", false);
                    anim.SetInteger("condition", 0);
                }
               if(anim.GetBool("running") == false)
                    {
                    Attacking();
                }
			
			}
		
	}
	void Attacking()
	{
        anim.SetBool("attacking", true);
        anim.SetInteger("condition", 2);
        StartCoroutine(AttackRoutine());
        anim.SetBool("attacking", false);
         

    }
    IEnumerator AttackRoutine()
    {
        yield return new WaitForSeconds(1);
    }
}
