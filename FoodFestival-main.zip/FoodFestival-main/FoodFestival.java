

//////////////////////// VIDEO https://youtu.be/Z2XLnbhccuU ////////////////////////////////////////////////////

import java.nio.file.attribute.UserPrincipalLookupService;
import java.security.KeyStore.TrustedCertificateEntry;
import java.util.Scanner;

import javax.imageio.ImageTranscoder;
import javax.swing.DefaultSingleSelectionModel;

public class FoodFestival {

	 public static void main(String[] args) {

		 String userInput;
		 boolean Choice = false;
		 Scanner scnr = new Scanner(System.in);


		 while (Choice == false) {

		 System.out.println("Welcome to the food festival!");
		 System.out.println("Would you like to place an order?");
		 System.out.println("Please enter yes or no");
		 userInput = scnr.nextLine();

		 if(userInput.equalsIgnoreCase("Yes")) {

		 Choice = true;

		 }
		 else if(userInput.equalsIgnoreCase("No")) {

		 System.out.println("Thank you for stopping by, maybe next time you�ll sample our menu.");
		 return;
		 } else {

		 Choice = false;
		 }//To get out of the loop

		 }//END WHILE LOOP


		 if(Choice == true) {
		 System.out.println("What is your name for the order?");
		 userInput = scnr.nextLine();

		 System.out.println("Hello " + userInput + " What would you have today? enter 0-3 to select");
		 }// End if statement choice = true


		 MainMenu();

		 }// End Main Method


		 public static void MainMenu() {

		 int userInput;
		 Scanner scnr = new Scanner(System.in);
		 System.out.println("What are you getting? \n0-nothing\n1-Appetizer\n2-Main Course\n3-Dessert");
		 userInput = scnr.nextInt();
		 String mainCourse = "";
		 String Desert = "";
		 String Appetizer = "";
		 String toppings = "";

		 if(userInput == 1) {


		 Appetizer = AppetizerMenu(Appetizer, toppings) + toppings;

		 } //AppetizerMenu

		 else if(userInput == 2) {

		 mainCourse = MainCourseMenu(mainCourse);
		   
		 } // MainCourse


		 else if(userInput == 3){
		 Desert = DesertMenu(Desert);
		 } //Desert Menu

		   
		   
		 System.out.println(""+mainCourse + "" +Appetizer + "\n" + Desert);
		   
		   

		 }
		   
		 public static String MainCourseMenu(String userReturn) {
		 int userChoice;

		 Scanner scnr = new Scanner(System.in);
		 System.out.println("Main Course Menu :\n0-Nothing\n1-Fried Shrimp && Fries\n2-Fish and chips\n3-Lobster Roll");
		 userChoice = scnr.nextInt();
		 if(userChoice == 0) {
		   
		 MainMenu();
		 }
		 if(userChoice == 1) {
		 userReturn ="Main course: Fried Shrimp && Fries";

		 MainMenu();
		 }
		 else if(userChoice == 2) {
		 userReturn = "Main course: Fish and chips";
		 MainMenu();
		 }
		 else if(userChoice == 3) {
		 userReturn = "Main course: Lobster Roll";
		 MainMenu();
		 }

		 return userReturn;

		 }

		 public static String AppetizerMenu(String UserChoice, String toppings) {
		 int userChoosing;
		 Scanner scnr = new Scanner(System.in);

		 System.out.println("Appetizer Menu :\n0-Nothing\n1-mozzarella sticks\n2-Oysters\n3-Clams");
		 userChoosing = scnr.nextInt();

		 String toppingFinal = "";

		 if(userChoosing == 0 ) {
		   
		 MainMenu();

		 }

		 else if(userChoosing == 1 ) {
		 UserChoice = "Appetizer chosen: mozzeralla sticks";
		 toppingFinal = ToppingsMenu(toppings);

		 }
		 else if(userChoosing == 2 ) {
		 UserChoice = "Appetizer Chosen: Oysters";
		 toppingFinal = ToppingsMenu(toppings);


		 }
		 else if(userChoosing == 3 ) {
		 UserChoice = "Appetizer Chosen: Clams";
		 toppingFinal= ToppingsMenu(toppings);

		 }
		 return UserChoice +" " +toppingFinal;


		 }


		 public static String ToppingsMenu(String toppingChoice) {
		 int userChoice;
		 String Choice1 = "";
		 String Choice2 = "";
		 String Choice3 = "";
		 boolean Choice = false;
		 Scanner scnr = new Scanner(System.in);

		 while(Choice == false) {

		 System.out.println("Toppings Menu :\n0-Nothing\n1-Hot Sauce\n2-Olive Oil\n3-Ketchup");
		 userChoice =scnr.nextInt();


		 if(userChoice == 1) {
		 Choice1 += " Hot Sauce";
		 Choice = false;

		 }

		 if(userChoice == 2) {
		 Choice2 += " Olive Oil";
		 Choice = false;

		 }

		 if(userChoice == 3) {
		 Choice3 += " Ketchup";
		 Choice = false;

		 }

		 if(userChoice == 0) {
		 Choice = true;
		 AppetizerMenu(toppingChoice, toppingChoice);
		 return toppingChoice;
		 }
		   
		 toppingChoice = Choice1 + " " + Choice2 +" " + Choice3;

		 } // END WHILE LOOP

		 return toppingChoice;

		 }


		 public static String DesertMenu(String userChosen) {
		 System.out.println("Desert Menu :\n0-Nothing\n1-Oreo CheeseCake\n2-Pumpkin Pie\n3-Strawberry Short Cake");

		 int userChoice;
		 Scanner scnr = new Scanner(System.in);

		 userChoice = scnr.nextInt();
		 if(userChoice == 0) {
		 userChosen = "Desert Chosen : Nothing";
		 MainMenu();
		 }
		 else if(userChoice == 1) {
		 userChosen = "Desert Chosen : Oreo CheeseCake";
		 MainMenu();
		 }
		 else if(userChoice == 2) {
		 userChosen = "Desert Chosen : Pumpkin Pie";
		 MainMenu();
		 }
		 else if(userChoice == 3) {
		 userChosen = " Desert Chosen: Strawberry Short Cake";
		 MainMenu();
		 }
		 return userChosen;


		 }




} // END CLASS
