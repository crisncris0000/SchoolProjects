# This is a food festival project which will allow the user to order what kinds of food they want
and when they are finish with their order it will tell you the order you have selected
