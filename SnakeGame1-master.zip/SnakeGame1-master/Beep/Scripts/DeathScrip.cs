﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathScrip : MonoBehaviour
{
    public Transform target;
    public Transform target2;
    public Transform target3;
    Rigidbody rb;
    public float forceAmt = 10f;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }
  
  //Death Collider
    void OnCollisionEnter(Collision colReport)
    {
        if (colReport.gameObject.name == "Rattlesnake (1)")
        {
            Destroy(colReport.gameObject);
        }
        if (colReport.gameObject.name == "RattleSnake2")
        {
            Destroy(colReport.gameObject);
        }
        if (colReport.gameObject.name == "RattleSnake3")
        {
            Destroy(colReport.gameObject);
        }



    }
    


    }
