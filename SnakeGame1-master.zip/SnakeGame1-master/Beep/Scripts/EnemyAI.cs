﻿using UnityEngine;

public class EnemyAI : MonoBehaviour
{


    Transform playerTransform;
    UnityEngine.AI.NavMeshAgent myNavMesh;
    public float checkRate = 0.01f;
    float nextCheck;



    // Start is called before the first frame update
    void Start()
    {
        if (GameObject.FindGameObjectWithTag("Player").activeInHierarchy)
            playerTransform = GameObject.FindGameObjectWithTag("Player").transform;

        myNavMesh = gameObject.GetComponent<UnityEngine.AI.NavMeshAgent>();
        


    }

    // Update is called once per frame
    void Update()
    {
        if (Time.time > nextCheck)
        {
            nextCheck = Time.time + checkRate;
            Follow();
        }
        
    }
    void Follow()
    {

        myNavMesh.transform.LookAt(playerTransform);
        myNavMesh.destination -= playerTransform.position;
    }
    }

